

package com.webapp.controller;



import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.google.gson.Gson;
import com.webapp.paymentmethod.BillingDetails;
import com.webapp.paymentmethod.Card;
import com.webapp.paymentmethod.CardExpiry;
import com.webapp.paymentmethod.Payment;
import com.webapp.paymentmethod.ReturnLinks;
import com.webapp.repository.BillingDetailsRepository;
import com.webapp.repository.CardExpiryRepository;
import com.webapp.repository.CardRepository;
import com.webapp.repository.PaymentRepository;
import com.webapp.repository.ReturnLinksRepository;



@RestController
@RequestMapping("/payment/method")
public class PaymentMethodcontroller
{

	@Autowired
	private PaymentRepository repository;
	
	@Autowired
	private BillingDetailsRepository billingRepository;
	
	@Autowired
	private CardRepository cardRepository;
	
	@Autowired
	private CardExpiryRepository cardExpiryRepository;
	@Autowired
	private ReturnLinksRepository returnLinksRepository;

	@GetMapping("/readAll")
	public String readAll() {
		Iterable<com.webapp.paymentmethod.Payment> all = repository.findAll();
		Gson gson = new Gson();
		String json = gson.toJson(all);

		JSONArray j1 = new JSONArray(json);
		JSONObject res = new JSONObject(j1.get(0).toString());

		Iterable< BillingDetails> billingResponse = billingRepository.findAll();

		json = gson.toJson(billingResponse);
		JSONObject billingJson = new JSONObject(new JSONArray(json).get(0).toString());
		res.put("BillingDetails", billingJson);

		// to get card

		Iterable<Card> cardResponse = cardRepository.findAll();

		json = gson.toJson(cardResponse);
		JSONObject cardJson = new JSONObject(new JSONArray(json).get(0).toString());
		// GET the card expiry
		Iterable<CardExpiry> cardExpiry = cardExpiryRepository.findAll();

		json = gson.toJson(cardExpiry);
		JSONObject cardExpiryJson = new JSONObject(new JSONArray(json).get(0).toString());
		cardJson.put("caredExpiry", cardExpiryJson);

		res.put("card", cardJson);
		
		
		Iterable<ReturnLinks> returnlinks = returnLinksRepository.findAll();

		json = gson.toJson(returnlinks);
		
		res.put("returnlinks", new JSONArray(json));
		
		return res.toString();
		
	
	}

	@PostMapping("/create")
	public Payment create(@RequestBody Payment payment)
	{
		return repository.save(payment);
	}

	@PutMapping("/update")
	public Payment update(@RequestBody Payment payment)
	{
		return repository.save(payment);
	}


	@DeleteMapping("/delete/{id}")
	public void delete(@PathVariable int id) {
		repository.deleteById(id);
	}

}