package com.webapp.repository;

import org.springframework.data.repository.CrudRepository;

import com.webapp.paymentmethod.Card;



public interface CardRepository extends CrudRepository<Card,Integer>{

}
