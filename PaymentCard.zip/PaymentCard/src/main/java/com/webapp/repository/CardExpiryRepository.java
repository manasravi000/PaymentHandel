package com.webapp.repository;

import org.springframework.data.repository.CrudRepository;

import com.webapp.paymentmethod.CardExpiry;



public interface CardExpiryRepository extends CrudRepository<CardExpiry,Integer> {

}
