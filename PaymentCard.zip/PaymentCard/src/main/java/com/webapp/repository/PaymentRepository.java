package com.webapp.repository;

import org.springframework.data.repository.CrudRepository;

import com.webapp.paymentmethod.Payment;

public interface PaymentRepository extends CrudRepository<Payment,Integer>{

}

