package com.webapp.repository;

import org.springframework.data.repository.CrudRepository;

import com.webapp.paymentmethod.BillingDetails;


public interface BillingDetailsRepository extends CrudRepository<BillingDetails,Integer> {

}
