package com.webapp.paymentmethod;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CardExpiry {
	@Id
	private int month;
	private int year;
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	@Override
	public String toString() {
		return "CardExpiry [month=" + month + ", year=" + year + "]";
	}
	public void setYear(int year) {
		this.year = year;
	}
	

}
