package com.webapp.paymentmethod;


import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Card {

String holderName;
String cardType;
@Id
long cardBin;
int lastDigits;




public String getHolderName() {
	return holderName;
}
public void setHolderName(String holderName) {
	this.holderName = holderName;
}
public String getCardType() {
	return cardType;
}
public void setCardType(String cardType) {
	this.cardType = cardType;
}
public long getCardBin() {
	return cardBin;
}
public void setCardBin(long cardBin) {
	this.cardBin = cardBin;
}
public int getLastDigits() {
	return lastDigits;
}
public void setLastDigits(int lastDigits) {
	this.lastDigits = lastDigits;
}
}
