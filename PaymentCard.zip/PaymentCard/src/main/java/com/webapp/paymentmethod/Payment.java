package com.webapp.paymentmethod;


import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Payment {
	@Id
	String id; 
	 int amount;
	 String merchantRefNum;
	  String action;
	  String currencyCode;
	 String usage1;
	  String status;
	  int timeToLiveSeconds;
	  String transactionType;
	  String paymentType;
	  String executionMode;
	  String customerIp;
	  String paymentHandleToken;
	
	  
	@Override
	public String toString() {
		return "Payment [id=" + id + ", amount=" + amount + ", merchantRefNum=" + merchantRefNum + ", action=" + action
				+ ", currencyCode=" + currencyCode + ", usage=" + usage1 + ", status=" + status + ", timeToLiveSeconds="
				+ timeToLiveSeconds + ", transactionType=" + transactionType + ", paymentType=" + paymentType
				+ ", executionMode=" + executionMode + ", customerIp=" + customerIp + ", paymentHandleToken="
				+ paymentHandleToken + "]";
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getMerchantRefNum() {
		return merchantRefNum;
	}
	public void setMerchantRefNum(String merchantRefNum) {
		this.merchantRefNum = merchantRefNum;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getUsage() {
		return usage1;
	}
	public void setUsage(String usage) {
		this.usage1 = usage;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getTimeToLiveSeconds() {
		return timeToLiveSeconds;
	}
	public void setTimeToLiveSeconds(int timeToLiveSeconds) {
		this.timeToLiveSeconds = timeToLiveSeconds;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public String getExecutionMode() {
		return executionMode;
	}
	public void setExecutionMode(String executionMode) {
		this.executionMode = executionMode;
	}
	public String getCustomerIp() {
		return customerIp;
	}
	public void setCustomerIp(String customerIp) {
		this.customerIp = customerIp;
	}
	public String getPaymentHandleToken() {
		return paymentHandleToken;
	}
	public void setPaymentHandleToken(String paymentHandleToken) {
		this.paymentHandleToken = paymentHandleToken;
	}
	
}
