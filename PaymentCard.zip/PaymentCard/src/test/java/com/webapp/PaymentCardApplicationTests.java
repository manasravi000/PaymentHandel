package com.webapp;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;


@SpringBootTest
class PaymentCardApplicationTests {
	
	
	@Autowired
	ApplicationContext context;

	@Test
	void savePayment() {
		
		
	    
	}

}
